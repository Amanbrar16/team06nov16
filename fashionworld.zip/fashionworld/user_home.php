
<?php

session_start();
include_once('header.html');
include_once('functions/config.php');
if(isset($_SESSION['user_id'])){
	$id=$_SESSION['user_id'];
	$conn= db_connect();
	$sql = "select * from user where id='$id'";
	$result= $conn -> query($sql);
	$row= mysqli_fetch_assoc($result);
	?>
	<div class="container">
    <div class="row text-center">
    <div class="col-md-4 m-b-lg">
          <div class="panel panel-default panel-profile m-b-0">
            <div class="panel-body text-center">
              <h5 class="panel-title text-uppercase">Name :<?php echo $row['name']; ?></h5>
              <p class="m-b">
              <span class="glyphicon glyphicone-phone"> Email:<?php echo $row['email'];?></span>
              </p>
              <p class="m-b">
              <span class="glyphicon glyphicone-phone"> Phone:<?php echo $row['phone'];?></span>
              </p>
              </div>
          </div>
        </div>
    <i><a href="functions/logout.php" class="btn btn-danger">Logout</a> </i>
    </div>
    </div>
    
    
    
	
	
<?php 
	}
else{
	header('location:Login.php');
	}	
include_once('footer.html');?>