<?php include_once('header.html');?>
<div class="container">
<div class="row">	
<div class="text-center">
<p class="text-danger"> Fashion Wear</p>


<div class="row">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3539.5642105221955!2d153.04053871443023!3d-27.482823423839545!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b915a3c16d5b4e5%3A0x27333df9bea164aa!2s3+Geelong+St%2C+East+Brisbane+QLD+4169!5e0!3m2!1sen!2sau!4v1485265649698" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

</div>



</div>
</div>

</div>
<?php include_once('footer.html');?>