<?php 
session_start();
include_once('config.php');
if (isset($_POST['email']) && isset($_POST['password']))
{
	print_r($_POST);
$username= $_POST['email'];
$password= $_POST['password'];
$conn= db_connect();
$sql="select * from user where email='$username' and password='$password'";
$result= $conn->query($sql);
$numOfRows = $result -> num_rows;
$row = mysqli_fetch_assoc($result);
if($numOfRows)
	{
		$_SESSION['user_id']=$row['id'];
		$_SESSION['user']=$row['name'];
	}
$conn ->close();
if (isset($_SESSION['user_id']))
{
	header('location:../user_home.php');	
}

}
else{
	header('location:../login.php');
	
	
	}

?>