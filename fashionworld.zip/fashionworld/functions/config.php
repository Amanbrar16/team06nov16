<?php
//define constants for connection info


//make connection to database
function db_connect()
{
$HOSTNAME="localhost";
$MYSQLUSER="root";
$MYSQLPASS="";
$MYSQLDB="team06nov16";
	$conn = @new mysqli($HOSTNAME, $MYSQLUSER, $MYSQLPASS, $MYSQLDB);
	if($conn -> connect_error) {
		die('Connect Error: ' . $conn -> connect_error);
	}
	//print ("true");
	return $conn;
} 

?>