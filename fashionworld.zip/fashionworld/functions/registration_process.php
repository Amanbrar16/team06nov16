<?php 
include_once('config.php');

if(isset($_POST['name'], $_POST['password'],$_POST['email'],$_POST['phone'] ))
{
print ('here post');	
$name = $_REQUEST['name'];
$password = $_POST['password'];
$email = $_POST['email'];
$phone = $_POST['phone'];

$conn =db_connect();

$sql= "Insert into team06nov16.user(name, email, password, phone) 
			VALUES ('$name', '$email', '$password','$phone')";		


if($conn->query($sql) === TRUE)
	{

		echo "<h1>Welcome to Fashion Wear</h1>";
		echo "Hi <b>$name</b><br />";
		echo "<a href=\"..\Login.php\">You can login now</a>";
	}
	else{
	echo "Error: " . $sql . "<br>" . $conn->error;
	$conn -> close();		
	}}
else {
	die("Input error");
}
?>